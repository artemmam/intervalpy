# Python interval library
Interval library for basic arithmetic operations and mathematical functions

